
======
## HTML & CSS Instagram

###Learning Objectives:

- Improve HTML skills
- Improve CSS skills
- Build something that the students will be familiar with

<br>
---

###Connection to a long term learning goal 

- Students should be confident with both front-end and back-end development.

<br>
---

###Before Homework

N/A.

<br>
---

HTML & CSS Instagram
=====

##Instructions

Given some starter, unformatted HTML and an image of the Instagram landing page, the students should try to replicate the image using HTML and CSS. 

<br>